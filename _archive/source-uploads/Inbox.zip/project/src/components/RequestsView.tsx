import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { formatRelativeDate } from '@/lib/utils';
import type { Request, Supplier } from '@/types';
import { FileText, ArrowRight, Mail, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

const STATUS_LABELS: Record<string, string> = {
  awaiting_reply: 'Ждём ответа',
  reply_received: 'Ответ получен',
  needs_processing: 'Нужна обработка',
};

const STATUS_COLORS: Record<string, string> = {
  awaiting_reply: 'text-amber-600 bg-amber-50',
  reply_received: 'text-emerald-600 bg-emerald-50',
  needs_processing: 'text-rose-600 bg-rose-50',
};

const STATUS_ICONS: Record<string, typeof Clock> = {
  awaiting_reply: Clock,
  reply_received: CheckCircle2,
  needs_processing: AlertCircle,
};

interface RequestsViewProps {
  onOpenRequest?: (request: Request) => void;
  onSendRequest?: (request: Request, supplier: Supplier | null) => void;
}

export function RequestsView({ onOpenRequest, onSendRequest }: RequestsViewProps) {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase
          .from('requests')
          .select('*, supplier:suppliers(*)')
          .order('created_at', { ascending: false });

        if (error) throw error;
        setRequests(data as unknown as Request[]);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="p-6 space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-24 rounded-xl bg-gray-100 animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="text-center py-16 text-gray-500">
          <p className="text-sm">Не удалось загрузить заявки</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-3 text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Повторить
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">Заявки</h1>
        <p className="text-sm text-gray-500 mt-1">Управление закупками и коммуникацией с поставщиками</p>
      </div>

      <div className="space-y-2.5">
        {requests.map((req) => {
          const StatusIcon = STATUS_ICONS[req.communication_status] || Clock;
          return (
            <div
              key={req.id}
              className="group bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                    <FileText size={18} className="text-gray-500" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-gray-400">{req.number}</span>
                      <span className="text-xs text-gray-300">·</span>
                      <span className="text-xs text-gray-400">{formatRelativeDate(req.created_at)}</span>
                    </div>
                    <h3 className="text-[15px] font-medium text-gray-900 truncate">{req.title}</h3>
                    {req.supplier && (
                      <p className="text-sm text-gray-500 mt-0.5 truncate">{req.supplier.name}</p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md ${STATUS_COLORS[req.communication_status] || ''}`}>
                        <StatusIcon size={12} />
                        {STATUS_LABELS[req.communication_status] || req.communication_status}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {req.supplier && (
                    <button
                      onClick={() => onSendRequest?.(req, req.supplier || null)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Mail size={15} />
                      Отправить запрос
                    </button>
                  )}
                  <button
                    onClick={() => onOpenRequest?.(req)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                  >
                    Открыть
                    <ArrowRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
