import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';
import { ThreadList } from '@/components/ThreadList';
import { ThreadDetail } from '@/components/ThreadDetail';
import { Composer, type ComposerContext } from '@/components/Composer';
import type { EmailThread, EmailMessage, Folder, MailMode, RequestFilter, Request, Supplier } from '@/types';
import { Mail } from 'lucide-react';

interface MailViewProps {
  preselectedThreadId?: string | null;
  composerContext?: ComposerContext | null;
  onComposerConsumed?: () => void;
  onOpenRequest?: (requestId: string) => void;
}

export function MailView({ preselectedThreadId, composerContext, onComposerConsumed, onOpenRequest }: MailViewProps) {
  const [mode, setMode] = useState<MailMode>('all');
  const [folder, setFolder] = useState<Folder>('inbox');
  const [requestFilter, setRequestFilter] = useState<RequestFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedThread, setSelectedThread] = useState<EmailThread | null>(null);
  const [composerOpen, setComposerOpen] = useState(false);
  const [composerCtx, setComposerCtx] = useState<ComposerContext | null>(null);
  const [composerRequest, setComposerRequest] = useState<Request | null>(null);
  const [composerSupplier, setComposerSupplier] = useState<Supplier | null>(null);
  const [retryKey, setRetryKey] = useState(0);
  const [folderCounts, setFolderCounts] = useState<Record<string, number>>({});
  const [filterCounts, setFilterCounts] = useState<Record<string, number>>({});

  const handleFolderCountsChange = useCallback((counts: Record<string, number>) => {
    setFolderCounts(counts);
  }, []);

  // Listen for retry events
  useEffect(() => {
    const handleRetry = () => setRetryKey((k) => k + 1);
    window.addEventListener('mail-retry', handleRetry);
    return () => window.removeEventListener('mail-retry', handleRetry);
  }, []);

  // Fetch request filter counts when in requests mode
  useEffect(() => {
    if (mode !== 'requests') return;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('email_threads')
          .select('request:requests(communication_status)')
          .not('request_id', 'is', null);
        if (error) throw error;
        const counts: Record<string, number> = { all: 0 };
        (data || []).forEach((t) => {
          const status = (t as unknown as { request: { communication_status: string } }).request?.communication_status;
          if (status) {
            counts.all = (counts.all || 0) + 1;
            counts[status] = (counts[status] || 0) + 1;
          }
        });
        setFilterCounts(counts);
      } catch {
        /* non-critical */
      }
    })();
  }, [mode, retryKey]);

  // Preselect thread from outside
  useEffect(() => {
    if (preselectedThreadId) {
      (async () => {
        const { data } = await supabase
          .from('email_threads')
          .select('*, request:requests(*, supplier:suppliers(*)), supplier:suppliers(*)')
          .eq('id', preselectedThreadId)
          .maybeSingle();
        if (data) setSelectedThread(data as unknown as EmailThread);
      })();
    }
  }, [preselectedThreadId]);

  // Open composer from external context
  useEffect(() => {
    if (composerContext) {
      setComposerCtx(composerContext);
      setComposerOpen(true);
      onComposerConsumed?.();
    }
  }, [composerContext, onComposerConsumed]);

  const handleSelectThread = (thread: EmailThread) => {
    setSelectedThread(thread);
  };

  const handleReply = (thread: EmailThread) => {
    const lastMsg = thread.last_message;
    const toEmail = lastMsg
      ? lastMsg.is_outbound
        ? lastMsg.to_email
        : lastMsg.from_email
      : '';
    setComposerCtx({
      to: toEmail,
      subject: thread.subject.startsWith('Re:') ? thread.subject : `Re: ${thread.subject}`,
      isReply: true,
      threadId: thread.id,
      requestId: thread.request_id || undefined,
      supplierId: thread.supplier_id || undefined,
    });
    setComposerRequest(thread.request || null);
    setComposerSupplier(thread.supplier || null);
    setComposerOpen(true);
  };

  const handleForward = (thread: EmailThread, message: EmailMessage) => {
    setComposerCtx({
      subject: thread.subject.startsWith('Fwd:') ? thread.subject : `Fwd: ${thread.subject}`,
      body: `<br><br><div style="border-left:3px solid #ccc;padding-left:12px;color:#666;"><p><strong>Пересылаемое сообщение</strong></p><p>От: ${message.from_name} &lt;${message.from_email}&gt;<br>Дата: ${message.sent_at}</p>${message.body_html || `<p>${message.body_text || ''}</p>`}</div>`,
      isForward: true,
    });
    setComposerRequest(thread.request || null);
    setComposerSupplier(thread.supplier || null);
    setComposerOpen(true);
  };

  const handleNewCompose = () => {
    setComposerCtx(null);
    setComposerRequest(null);
    setComposerSupplier(null);
    setComposerOpen(true);
  };

  const handleComposerSent = async () => {
    setRetryKey((k) => k + 1);
    setSelectedThread(null);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Top bar with segmented control */}
      <div className="h-14 border-b border-gray-200 bg-white flex items-center justify-between px-5 shrink-0">
        <h1 className="text-lg font-semibold text-gray-900 tracking-tight">Переписка</h1>

        {/* Segmented control */}
        <div className="flex items-center bg-gray-100 rounded-lg p-0.5">
          <button
            onClick={() => setMode('all')}
            className={cn(
              'px-4 py-1.5 text-sm font-medium rounded-md transition-all duration-200',
              mode === 'all'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-700',
            )}
          >
            Вся почта
          </button>
          <button
            onClick={() => setMode('requests')}
            className={cn(
              'px-4 py-1.5 text-sm font-medium rounded-md transition-all duration-200',
              mode === 'requests'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-700',
            )}
          >
            По заявкам
          </button>
        </div>
      </div>

      {/* Three-pane layout: ThreadList | Reading pane */}
      <div className="flex-1 flex overflow-hidden">
        {/* Thread list with integrated filter chips + search */}
        <ThreadList
          key={retryKey}
          mode={mode}
          folder={folder}
          requestFilter={requestFilter}
          searchQuery={searchQuery}
          selectedThreadId={selectedThread?.id || null}
          onSelectThread={handleSelectThread}
          onOpenComposer={handleNewCompose}
          onSearchChange={setSearchQuery}
          onFolderCountsChange={handleFolderCountsChange}
          onFolderChange={setFolder}
          onFilterChange={setRequestFilter}
          folderCounts={folderCounts}
          filterCounts={filterCounts}
        />

        {/* Reading pane */}
        {selectedThread ? (
          <ThreadDetail
            thread={selectedThread}
            onBack={() => setSelectedThread(null)}
            onReply={handleReply}
            onForward={handleForward}
            onOpenRequest={onOpenRequest}
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-gray-50/50 text-center px-6">
            <div className="w-16 h-16 rounded-2xl bg-white border border-gray-200 flex items-center justify-center mb-4 shadow-sm">
              <Mail size={28} className="text-gray-300" />
            </div>
            <p className="text-sm font-medium text-gray-500">Выберите письмо, чтобы прочитать его</p>
            <p className="text-xs text-gray-400 mt-1">Или нажмите «Написать», чтобы создать новое</p>
          </div>
        )}
      </div>

      {/* Composer modal */}
      {composerOpen && (
        <Composer
          context={composerCtx}
          request={composerRequest}
          supplier={composerSupplier}
          onClose={() => setComposerOpen(false)}
          onSent={handleComposerSent}
        />
      )}
    </div>
  );
}
