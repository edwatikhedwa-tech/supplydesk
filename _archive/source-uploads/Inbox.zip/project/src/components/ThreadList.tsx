import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { cn, formatRelativeDate } from '@/lib/utils';
import type { EmailThread, EmailMessage, Folder, MailMode, RequestFilter } from '@/types';
import { Search, Mail, ChevronDown, Inbox, Send, FileEdit, Archive } from 'lucide-react';

const FOLDERS: { id: Folder; label: string; icon: typeof Inbox }[] = [
  { id: 'inbox', label: 'Входящие', icon: Inbox },
  { id: 'sent', label: 'Отправленные', icon: Send },
  { id: 'drafts', label: 'Черновики', icon: FileEdit },
  { id: 'archive', label: 'Архив', icon: Archive },
];

const REQUEST_FILTERS: { id: RequestFilter; label: string }[] = [
  { id: 'all', label: 'Все' },
  { id: 'awaiting_reply', label: 'Ждём ответа' },
  { id: 'reply_received', label: 'Получен ответ' },
  { id: 'needs_processing', label: 'Нужна обработка' },
];

const PRIMARY_COUNT = 3;

interface ThreadListProps {
  mode: MailMode;
  folder: Folder;
  requestFilter: RequestFilter;
  searchQuery: string;
  selectedThreadId: string | null;
  onSelectThread: (thread: EmailThread) => void;
  onOpenComposer: () => void;
  onSearchChange: (query: string) => void;
  onFolderCountsChange: (counts: Record<string, number>) => void;
  onFolderChange: (folder: Folder) => void;
  onFilterChange: (filter: RequestFilter) => void;
  folderCounts: Record<string, number>;
  filterCounts: Record<string, number>;
}

interface ThreadRow extends EmailThread {
  last_message: EmailMessage | null;
}

export function ThreadList({
  mode,
  folder,
  requestFilter,
  searchQuery,
  selectedThreadId,
  onSelectThread,
  onOpenComposer,
  onSearchChange,
  onFolderCountsChange,
  onFolderChange,
  onFilterChange,
  folderCounts,
  filterCounts,
}: ThreadListProps) {
  const [threads, setThreads] = useState<ThreadRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [searchInput, setSearchInput] = useState(searchQuery);
  const [overflowOpen, setOverflowOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const overflowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSearchInput(searchQuery);
  }, [searchQuery]);

  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase
          .from('email_threads')
          .select('folder, unread_count');
        if (error) throw error;
        const counts: Record<string, number> = {};
        (data || []).forEach((t) => {
          counts[t.folder] = (counts[t.folder] || 0) + (t.unread_count || 0);
        });
        onFolderCountsChange(counts);
      } catch {
        /* counts are non-critical */
      }
    })();
  }, [threads, onFolderCountsChange]);

  useEffect(() => {
    let query = supabase
      .from('email_threads')
      .select(`
        *,
        request:requests(*, supplier:suppliers(*)),
        supplier:suppliers(*)
      `);

    if (mode === 'requests') {
      query = query.not('request_id', 'is', null);
    } else {
      query = query.eq('folder', folder);
    }

    if (mode === 'requests' && requestFilter !== 'all') {
      query = query.eq('request.communication_status', requestFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim();
      query = query.or(`subject.ilike.%${q}%,request.number.ilike.%${q}%,request.title.ilike.%${q}%,supplier.name.ilike.%${q}%`);
    }

    query = query.order('last_message_at', { ascending: false });

    (async () => {
      setLoading(true);
      setError(false);
      try {
        const { data, error } = await query;
        if (error) throw error;
        const threadData = (data || []) as unknown as EmailThread[];

        if (threadData.length === 0) {
          setThreads([]);
          setLoading(false);
          return;
        }

        const threadIds = threadData.map((t) => t.id);
        const { data: msgData } = await supabase
          .from('email_messages')
          .select('*')
          .in('thread_id', threadIds)
          .order('sent_at', { ascending: false });

        const msgByThread: Record<string, EmailMessage[]> = {};
        (msgData || []).forEach((m) => {
          if (!msgByThread[m.thread_id]) msgByThread[m.thread_id] = [];
          msgByThread[m.thread_id].push(m as EmailMessage);
        });

        const rows: ThreadRow[] = threadData.map((t) => ({
          ...t,
          last_message: msgByThread[t.id]?.[0] || null,
        }));

        setThreads(rows);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
  }, [mode, folder, requestFilter, searchQuery]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (overflowRef.current && !overflowRef.current.contains(e.target as Node)) {
        setOverflowOpen(false);
      }
    };
    if (overflowOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [overflowOpen]);

  const handleSearchChange = (value: string) => {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      onSearchChange(value);
    }, 250);
  };

  const items = mode === 'all' ? FOLDERS : REQUEST_FILTERS;
  const primaryItems = items.slice(0, PRIMARY_COUNT);
  const overflowItems = items.slice(PRIMARY_COUNT);
  const activeValue = mode === 'all' ? folder : requestFilter;
  const counts = mode === 'all' ? folderCounts : filterCounts;

  const handleChipClick = (id: string) => {
    if (mode === 'all') {
      onFolderChange(id as Folder);
    } else {
      onFilterChange(id as RequestFilter);
    }
  };

  return (
    <div className="w-[360px] shrink-0 border-r border-gray-200 bg-white flex flex-col">
      {/* Header: filter chips + search */}
      <div className="px-3 pt-3 pb-2.5 border-b border-gray-100 shrink-0">
        {/* Filter chips row */}
        <div className="flex items-center gap-1.5 mb-2.5">
          {primaryItems.map((item) => {
            const active = activeValue === item.id;
            const count = counts[item.id] || 0;
            return (
              <button
                key={item.id}
                onClick={() => handleChipClick(item.id)}
                className={cn(
                  'flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap',
                  active
                    ? 'bg-gray-900 text-white'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100',
                )}
              >
                {item.label}
                {count > 0 && (
                  <span className={cn(
                    'text-[10px] font-semibold',
                    active ? 'text-gray-300' : 'text-gray-400',
                  )}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}

          {/* Overflow dropdown */}
          {overflowItems.length > 0 && (
            <div className="relative" ref={overflowRef}>
              <button
                onClick={() => setOverflowOpen((v) => !v)}
                className={cn(
                  'flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap',
                  overflowItems.some((i) => i.id === activeValue)
                    ? 'bg-gray-900 text-white'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100',
                )}
              >
                Ещё
                <ChevronDown size={12} />
              </button>
              {overflowOpen && (
                <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg py-1 min-w-[160px] z-30">
                  {overflowItems.map((item) => {
                    const active = activeValue === item.id;
                    const count = counts[item.id] || 0;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          handleChipClick(item.id);
                          setOverflowOpen(false);
                        }}
                        className={cn(
                          'w-full flex items-center justify-between gap-3 px-3 py-1.5 text-xs transition-colors',
                          active ? 'text-gray-900 font-medium' : 'text-gray-600 hover:bg-gray-50',
                        )}
                      >
                        <span>{item.label}</span>
                        {count > 0 && (
                          <span className="text-[10px] font-semibold text-gray-400">{count}</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder="Поиск по поставщику, заявке или письму..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-400"
          />
        </div>
      </div>

      {/* Thread list */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-3 space-y-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="p-3 space-y-2">
                <div className="h-3 w-1/2 bg-gray-100 rounded animate-pulse" />
                <div className="h-3 w-3/4 bg-gray-100 rounded animate-pulse" />
                <div className="h-3 w-2/3 bg-gray-100 rounded animate-pulse" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="p-6 text-center">
            <p className="text-sm text-gray-500">Не удалось загрузить письма</p>
            <button
              onClick={() => {
                const event = new CustomEvent('mail-retry');
                window.dispatchEvent(event);
              }}
              className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              Повторить
            </button>
          </div>
        ) : threads.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
            <Mail size={32} className="text-gray-300 mb-3" />
            <p className="text-sm text-gray-400">
              {mode === 'requests'
                ? 'Нет писем, связанных с заявками'
                : 'Нет писем'}
            </p>
          </div>
        ) : (
          <div className="py-1">
            {threads.map((thread) => {
              const isSelected = selectedThreadId === thread.id;
              const isUnread = thread.unread_count > 0;
              const lastMsg = thread.last_message;
              const fromName = lastMsg
                ? lastMsg.is_outbound
                  ? `Вы → ${lastMsg.to_email}`
                  : lastMsg.from_name
                : '';

              return (
                <button
                  key={thread.id}
                  onClick={() => onSelectThread(thread)}
                  className={cn(
                    'w-full px-3 py-2.5 text-left transition-colors border-l-2',
                    isSelected
                      ? 'bg-blue-50/50 border-blue-500'
                      : 'border-transparent hover:bg-gray-50',
                  )}
                >
                  <div className="flex items-start gap-2.5">
                    {/* Unread dot */}
                    <div className="pt-1 shrink-0">
                      {isUnread ? (
                        <span className="block w-2 h-2 rounded-full bg-blue-500" />
                      ) : (
                        <span className="block w-2 h-2 rounded-full bg-transparent" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      {/* Sender + date */}
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className={cn(
                          'text-sm truncate',
                          isUnread ? 'font-semibold text-gray-900' : 'font-medium text-gray-700',
                        )}>
                          {fromName}
                        </span>
                        <span className="text-[11px] text-gray-400 shrink-0">
                          {formatRelativeDate(thread.last_message_at)}
                        </span>
                      </div>

                      {/* Subject */}
                      <p className={cn(
                        'text-[13px] truncate mb-0.5',
                        isUnread ? 'font-medium text-gray-800' : 'text-gray-600',
                      )}>
                        {thread.subject}
                      </p>

                      {/* Preview */}
                      <p className="text-xs text-gray-400 truncate">
                        {lastMsg?.body_text || 'Нет содержимого'}
                      </p>

                      {/* Request context */}
                      {thread.request && (
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <span className="text-[11px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded font-medium truncate">
                            {thread.request.title} · {thread.request.number}
                          </span>
                          {thread.unread_count > 1 && (
                            <span className="text-[10px] font-semibold text-blue-600 ml-auto">
                              {thread.unread_count}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Write button */}
      <div className="p-3 border-t border-gray-100">
        <button
          onClick={onOpenComposer}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-gray-900 hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Mail size={16} />
          Написать
        </button>
      </div>
    </div>
  );
}
