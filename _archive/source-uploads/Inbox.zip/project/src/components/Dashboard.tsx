import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { formatRelativeDate } from '@/lib/utils';
import type { Request, EmailThread, EmailMessage } from '@/types';
import { FileText, Mail, Clock, CheckCircle2, AlertCircle, ArrowRight, TrendingUp } from 'lucide-react';

const STATUS_LABELS: Record<string, string> = {
  awaiting_reply: 'Ждём ответа',
  reply_received: 'Ответ получен',
  needs_processing: 'Нужна обработка',
};

const STATUS_COLORS: Record<string, string> = {
  awaiting_reply: 'text-amber-600 bg-amber-50',
  reply_received: 'text-emerald-600 bg-emerald-50',
  needs_processing: 'text-rose-600 bg-rose-50',
};

interface DashboardProps {
  onNavigateMail: () => void;
  onNavigateRequests: () => void;
}

export function Dashboard({ onNavigateMail, onNavigateRequests }: DashboardProps) {
  const [requests, setRequests] = useState<Request[]>([]);
  const [threads, setThreads] = useState<EmailThread[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [{ data: reqData }, { data: threadData }] = await Promise.all([
          supabase.from('requests').select('*, supplier:suppliers(*)').order('created_at', { ascending: false }),
          supabase.from('email_threads').select('*').order('last_message_at', { ascending: false }).limit(5),
        ]);
        setRequests((reqData as unknown as Request[]) || []);
        setThreads((threadData as unknown as EmailThread[]) || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const unreadCount = threads.filter((t) => t.unread_count > 0).length;
  const awaitingCount = requests.filter((r) => r.communication_status === 'awaiting_reply').length;
  const replyCount = requests.filter((r) => r.communication_status === 'reply_received').length;
  const processingCount = requests.filter((r) => r.communication_status === 'needs_processing').length;

  if (loading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-8 w-48 bg-gray-100 rounded animate-pulse" />
        <div className="grid grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">Дашборд</h1>
        <p className="text-sm text-gray-500 mt-1">Обзор активности и статусов заявок</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <StatCard icon={Mail} label="Непрочитанных" value={unreadCount} color="text-blue-600 bg-blue-50" onClick={onNavigateMail} />
        <StatCard icon={Clock} label="Ждём ответа" value={awaitingCount} color="text-amber-600 bg-amber-50" onClick={onNavigateRequests} />
        <StatCard icon={CheckCircle2} label="Ответов получено" value={replyCount} color="text-emerald-600 bg-emerald-50" onClick={onNavigateRequests} />
        <StatCard icon={AlertCircle} label="Нужна обработка" value={processingCount} color="text-rose-600 bg-rose-50" onClick={onNavigateRequests} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Recent requests */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-900">Последние заявки</h2>
            <button onClick={onNavigateRequests} className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
              Все заявки <ArrowRight size={12} />
            </button>
          </div>
          <div className="space-y-2">
            {requests.slice(0, 4).map((req) => (
              <div key={req.id} className="flex items-center gap-3 bg-white border border-gray-200 rounded-lg p-3">
                <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                  <FileText size={15} className="text-gray-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate">{req.title}</p>
                  <p className="text-xs text-gray-400">{req.number} · {req.supplier?.name || '—'}</p>
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${STATUS_COLORS[req.communication_status] || ''}`}>
                  {STATUS_LABELS[req.communication_status] || req.communication_status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent emails */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-900">Последние письма</h2>
            <button onClick={onNavigateMail} className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
              Вся почта <ArrowRight size={12} />
            </button>
          </div>
          <div className="space-y-2">
            {threads.map((thread) => (
              <div key={thread.id} className="flex items-center gap-3 bg-white border border-gray-200 rounded-lg p-3">
                <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                  <Mail size={15} className="text-gray-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate">{thread.subject}</p>
                  <p className="text-xs text-gray-400">{formatRelativeDate(thread.last_message_at)}</p>
                </div>
                {thread.unread_count > 0 && (
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, onClick }: {
  icon: typeof Mail;
  label: string;
  value: number;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="bg-white border border-gray-200 rounded-xl p-4 text-left hover:border-gray-300 hover:shadow-sm transition-all"
    >
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-2.5 ${color}`}>
        <Icon size={18} />
      </div>
      <p className="text-2xl font-semibold text-gray-900">{value}</p>
      <p className="text-xs text-gray-400 mt-0.5">{label}</p>
    </button>
  );
}
