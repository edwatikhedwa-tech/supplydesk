import { Inbox, FileText, LayoutDashboard, PanelLeftClose, PanelLeftOpen, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

export type View = 'dashboard' | 'requests' | 'mail';

interface SidebarProps {
  current: View;
  onNavigate: (view: View) => void;
  unreadCount: number;
  compact: boolean;
  onToggleCompact: () => void;
}

const NAV_ITEMS: { id: View; label: string; icon: typeof Inbox }[] = [
  { id: 'dashboard', label: 'Дашборд', icon: LayoutDashboard },
  { id: 'requests', label: 'Заявки', icon: FileText },
  { id: 'mail', label: 'Переписка', icon: Inbox },
];

const EXPANDED_WIDTH = 'w-60';
const COMPACT_WIDTH = 'w-[60px]';

export function Sidebar({ current, onNavigate, unreadCount, compact, onToggleCompact }: SidebarProps) {
  return (
    <aside
      className={cn(
        'shrink-0 border-r border-gray-200 bg-white flex flex-col transition-all duration-200 ease-in-out',
        compact ? COMPACT_WIDTH : EXPANDED_WIDTH,
      )}
    >
      {/* Logo */}
      <div className={cn(
        'h-14 flex items-center border-b border-gray-200 shrink-0',
        compact ? 'justify-center px-0' : 'gap-2.5 px-5',
      )}>
        <div className="w-8 h-8 rounded-lg bg-gray-900 flex items-center justify-center shrink-0">
          <span className="text-white font-bold text-sm">S</span>
        </div>
        {!compact && (
          <span className="font-semibold text-gray-900 text-[15px] tracking-tight whitespace-nowrap">Supplydesk</span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 px-2 space-y-0.5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = current === item.id;
          return (
            <div key={item.id} className="relative group">
              <button
                onClick={() => onNavigate(item.id)}
                className={cn(
                  'w-full flex items-center rounded-lg text-sm font-medium transition-colors duration-150',
                  compact ? 'justify-center px-0 py-2.5' : 'gap-3 px-3 py-2',
                  active
                    ? 'bg-gray-100 text-gray-900'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900',
                )}
              >
                <Icon size={18} strokeWidth={active ? 2.2 : 1.8} className="shrink-0" />
                {!compact && <span className="flex-1 text-left whitespace-nowrap">{item.label}</span>}
                {!compact && item.id === 'mail' && unreadCount > 0 && (
                  <span className="text-[11px] font-semibold bg-blue-600 text-white px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                    {unreadCount}
                  </span>
                )}
              </button>
              {/* Tooltip in compact mode */}
              {compact && (
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1.5 bg-gray-900 text-white text-xs font-medium rounded-md shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity duration-150 whitespace-nowrap z-50">
                  {item.label}
                  {item.id === 'mail' && unreadCount > 0 && (
                    <span className="ml-1.5 text-blue-300">{unreadCount}</span>
                  )}
                </div>
              )}
              {/* Active indicator bar in compact mode */}
              {compact && active && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-gray-900 rounded-r-full" />
              )}
            </div>
          );
        })}
      </nav>

      {/* Expand/Collapse toggle */}
      <div className={cn('px-2 pb-1.5', compact ? 'flex justify-center' : '')}>
        <button
          onClick={onToggleCompact}
          className={cn(
            'flex items-center gap-2.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-50 transition-colors text-xs font-medium',
            compact ? 'justify-center p-2.5' : 'px-3 py-2 w-full',
          )}
        >
          {compact ? <PanelLeftOpen size={18} /> : <PanelLeftClose size={16} />}
          {!compact && <span className="whitespace-nowrap">Свернуть навигацию</span>}
        </button>
      </div>

      {/* Settings */}
      <div className={cn('px-2 pb-1.5', compact ? 'flex justify-center' : '')}>
        <div className="relative group">
          <button
            className={cn(
              'flex items-center gap-2.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-50 transition-colors text-xs font-medium',
              compact ? 'justify-center p-2.5' : 'px-3 py-2 w-full',
            )}
          >
            <Settings size={compact ? 18 : 16} />
            {!compact && <span className="whitespace-nowrap">Настройки</span>}
          </button>
          {compact && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1.5 bg-gray-900 text-white text-xs font-medium rounded-md shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity duration-150 whitespace-nowrap z-50">
              Настройки
            </div>
          )}
        </div>
      </div>

      {/* Profile */}
      <div className="p-2 border-t border-gray-200">
        <div className="relative group">
          <div className={cn(
            'flex items-center rounded-lg',
            compact ? 'justify-center px-0 py-2' : 'gap-2.5 px-2 py-2',
          )}>
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
              <span className="text-xs font-semibold text-gray-600">МН</span>
            </div>
            {!compact && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">Менеджер</p>
                <p className="text-xs text-gray-400 truncate">manager@supplydesk.ru</p>
              </div>
            )}
          </div>
          {compact && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1.5 bg-gray-900 text-white text-xs font-medium rounded-md shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity duration-150 whitespace-nowrap z-50">
              Менеджер
              <span className="block text-gray-400 font-normal">manager@supplydesk.ru</span>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
