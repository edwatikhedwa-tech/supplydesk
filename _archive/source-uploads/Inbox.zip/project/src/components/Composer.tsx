import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { cn, formatFileSize } from '@/lib/utils';
import type { EmailThread, Request, Supplier } from '@/types';
import {
  X, Send, Save, Paperclip, FileText, ExternalLink, Loader2,
  Bold, Italic, List, ListOrdered, Link as LinkIcon,
} from 'lucide-react';

export interface ComposerContext {
  to?: string;
  toName?: string;
  cc?: string;
  subject?: string;
  body?: string;
  requestId?: string;
  supplierId?: string;
  threadId?: string;
  isReply?: boolean;
  isForward?: boolean;
}

interface ComposerProps {
  context: ComposerContext | null;
  request?: Request | null;
  supplier?: Supplier | null;
  onClose: () => void;
  onSent: () => void;
}

interface PendingAttachment {
  id: string;
  filename: string;
  mime_type: string;
  size_bytes: number;
}

export function Composer({ context, request, supplier, onClose, onSent }: ComposerProps) {
  const [to, setTo] = useState(context?.to || '');
  const [cc, setCc] = useState(context?.cc || '');
  const [showCc, setShowCc] = useState(!!context?.cc);
  const [subject, setSubject] = useState(context?.subject || '');
  const [body, setBody] = useState(context?.body || '');
  const [attachments, setAttachments] = useState<PendingAttachment[]>([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);
  const editorRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (context) {
      setTo(context.to || '');
      setCc(context.cc || '');
      setShowCc(!!context.cc);
      setSubject(context.subject || '');
      setBody(context.body || '');
      if (editorRef.current && context.body) {
        editorRef.current.innerHTML = context.body;
      }
    }
  }, [context]);

  const exec = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newAtts = files.map((f) => ({
      id: crypto.randomUUID(),
      filename: f.name,
      mime_type: f.type || 'application/octet-stream',
      size_bytes: f.size,
    }));
    setAttachments((prev) => [...prev, ...newAtts]);
    e.target.value = '';
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSend = async () => {
    if (!to.trim() || !subject.trim()) return;
    setSending(true);
    setError(false);

    try {
      let threadId = context?.threadId;

      // Create new thread if not a reply
      if (!threadId) {
        const folder = 'sent';
        const { data: threadData, error: threadError } = await supabase
          .from('email_threads')
          .insert({
            subject,
            folder,
            request_id: context?.requestId || request?.id || null,
            supplier_id: context?.supplierId || supplier?.id || null,
            last_message_at: new Date().toISOString(),
            unread_count: 0,
          })
          .select('id')
          .single();

        if (threadError) throw threadError;
        threadId = threadData.id;
      }

      const htmlBody = editorRef.current?.innerHTML || `<p>${body}</p>`;

      const { data: msgData, error: msgError } = await supabase
        .from('email_messages')
        .insert({
          thread_id: threadId,
          from_name: 'Вы',
          from_email: 'manager@supplydesk.ru',
          to_email: to,
          cc_email: cc || null,
          body_html: htmlBody,
          body_text: editorRef.current?.innerText || body,
          is_outbound: true,
          is_read: true,
          sent_at: new Date().toISOString(),
        })
        .select('id')
        .single();

      if (msgError) throw msgError;

      // Save attachments
      if (attachments.length > 0 && msgData) {
        await supabase.from('email_attachments').insert(
          attachments.map((a) => ({
            ...a,
            message_id: msgData.id,
          })),
        );
      }

      // Update thread timestamp
      await supabase
        .from('email_threads')
        .update({ last_message_at: new Date().toISOString() })
        .eq('id', threadId);

      onSent();
      onClose();
    } catch {
      setError(true);
      setSending(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!to.trim() && !subject.trim()) {
      onClose();
      return;
    }
    setSending(true);
    try {
      const { data: threadData } = await supabase
        .from('email_threads')
        .insert({
          subject: subject || '(Без темы)',
          folder: 'drafts',
          request_id: context?.requestId || request?.id || null,
          supplier_id: context?.supplierId || supplier?.id || null,
          last_message_at: new Date().toISOString(),
          unread_count: 0,
        })
        .select('id')
        .single();

      if (threadData) {
        await supabase.from('email_messages').insert({
          thread_id: threadData.id,
          from_name: 'Вы',
          from_email: 'manager@supplydesk.ru',
          to_email: to,
          cc_email: cc || null,
          body_html: editorRef.current?.innerHTML || `<p>${body}</p>`,
          body_text: editorRef.current?.innerText || body,
          is_outbound: true,
          is_read: true,
          sent_at: new Date().toISOString(),
        });
      }
      onClose();
    } catch {
      setError(true);
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/20 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
          <h3 className="text-base font-semibold text-gray-900">
            {context?.isReply ? 'Ответить' : context?.isForward ? 'Переслать' : 'Новое письмо'}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 -mr-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Request context */}
        {request && (
          <div className="mx-5 mt-4 bg-blue-50/50 border border-blue-100 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-semibold text-blue-400 uppercase tracking-wider mb-0.5">Заявка</p>
                <p className="text-sm font-medium text-gray-900">
                  {request.title} · <span className="font-mono text-gray-500">{request.number}</span>
                </p>
              </div>
              <button className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium">
                Открыть заявку
                <ExternalLink size={12} />
              </button>
            </div>
          </div>
        )}

        {/* Form */}
        <div className="px-5 py-4 space-y-3">
          {/* To */}
          <div className="flex items-center gap-3 border-b border-gray-100 pb-2">
            <label className="text-sm text-gray-400 w-12 shrink-0">Кому</label>
            <input
              type="text"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="email@поставщик.ру"
              className="flex-1 text-sm bg-transparent border-none outline-none placeholder:text-gray-300"
            />
            {!showCc && (
              <button
                onClick={() => setShowCc(true)}
                className="text-xs text-gray-400 hover:text-gray-600"
              >
                + Копия
              </button>
            )}
          </div>

          {/* CC */}
          {showCc && (
            <div className="flex items-center gap-3 border-b border-gray-100 pb-2 animate-in fade-in slide-in-from-top-1 duration-150">
              <label className="text-sm text-gray-400 w-12 shrink-0">Копия</label>
              <input
                type="text"
                value={cc}
                onChange={(e) => setCc(e.target.value)}
                placeholder="email@копия.ру"
                className="flex-1 text-sm bg-transparent border-none outline-none placeholder:text-gray-300"
              />
            </div>
          )}

          {/* Subject */}
          <div className="flex items-center gap-3 border-b border-gray-100 pb-2">
            <label className="text-sm text-gray-400 w-12 shrink-0">Тема</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Тема письма"
              className="flex-1 text-sm bg-transparent border-none outline-none placeholder:text-gray-300"
            />
          </div>

          {/* Supplier info */}
          {supplier && (
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span>Получатель связан с поставщиком:</span>
              <span className="font-medium text-gray-600">{supplier.name}</span>
            </div>
          )}

          {/* Rich text editor */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            {/* Toolbar */}
            <div className="flex items-center gap-1 px-2 py-1.5 border-b border-gray-100 bg-gray-50">
              <ToolbarButton onClick={() => exec('bold')} icon={Bold} />
              <ToolbarButton onClick={() => exec('italic')} icon={Italic} />
              <ToolbarButton onClick={() => exec('insertUnorderedList')} icon={List} />
              <ToolbarButton onClick={() => exec('insertOrderedList')} icon={ListOrdered} />
              <ToolbarButton onClick={() => {
                const url = prompt('URL:');
                if (url) exec('createLink', url);
              }} icon={LinkIcon} />
              <div className="flex-1" />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1 px-2 py-1 text-xs text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded transition-colors"
              >
                <Paperclip size={14} />
                Вложить
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>

            {/* Editor area */}
            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              data-placeholder="Напишите письмо..."
              className="min-h-[140px] max-h-[280px] overflow-y-auto px-3 py-2.5 text-sm text-gray-800 outline-none focus:outline-none [&:empty]:before:content-[attr(data-placeholder)] [&:empty]:before:text-gray-300"
            />
          </div>

          {/* Attachments */}
          {attachments.length > 0 && (
            <div className="space-y-1.5">
              {attachments.map((att) => (
                <div key={att.id} className="flex items-center gap-2.5 bg-gray-50 border border-gray-200 rounded-lg p-2.5">
                  <Paperclip size={15} className="text-gray-400 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-700 truncate">{att.filename}</p>
                    <p className="text-xs text-gray-400">{formatFileSize(att.size_bytes)}</p>
                  </div>
                  <button
                    onClick={() => removeAttachment(att.id)}
                    className="p-1 text-gray-400 hover:text-gray-700 rounded transition-colors"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Error */}
          {error && (
            <p className="text-sm text-rose-600">Не удалось отправить. Попробуйте ещё раз.</p>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3.5 border-t border-gray-100 bg-gray-50">
          <button
            onClick={handleSaveDraft}
            disabled={sending}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
          >
            <Save size={15} />
            Черновик
          </button>
          <button
            onClick={handleSend}
            disabled={sending || !to.trim() || !subject.trim()}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sending ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Send size={16} />
            )}
            Отправить
          </button>
        </div>
      </div>
    </div>
  );
}

function ToolbarButton({ onClick, icon: Icon }: { onClick: () => void; icon: typeof Bold }) {
  return (
    <button
      onClick={onClick}
      className="p-1.5 text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition-colors"
    >
      <Icon size={15} />
    </button>
  );
}
