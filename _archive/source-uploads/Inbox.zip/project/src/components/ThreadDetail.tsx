import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { cn, formatFullDate, formatFileSize, getInitials, getAvatarColor } from '@/lib/utils';
import { EmailRenderer } from '@/components/EmailRenderer';
import type { EmailThread, EmailMessage, EmailAttachment } from '@/types';
import {
  ArrowLeft, Reply, Forward, Paperclip, Download, ChevronDown, ChevronUp,
  FileText, ExternalLink, UserX, Loader2,
} from 'lucide-react';

const COMM_STATUS_LABELS: Record<string, string> = {
  awaiting_reply: 'Ждём ответа',
  reply_received: 'Ответ получен',
  needs_processing: 'Нужна обработка',
};

const COMM_STATUS_COLORS: Record<string, string> = {
  awaiting_reply: 'text-amber-600 bg-amber-50',
  reply_received: 'text-emerald-600 bg-emerald-50',
  needs_processing: 'text-rose-600 bg-rose-50',
};

interface ThreadDetailProps {
  thread: EmailThread;
  onBack: () => void;
  onReply: (thread: EmailThread) => void;
  onForward: (thread: EmailThread, message: EmailMessage) => void;
  onOpenRequest?: (requestId: string) => void;
}

export function ThreadDetail({ thread, onBack, onReply, onForward, onOpenRequest }: ThreadDetailProps) {
  const [messages, setMessages] = useState<EmailMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(false);
      try {
        const { data, error } = await supabase
          .from('email_messages')
          .select('*, attachments:email_attachments(*)')
          .eq('thread_id', thread.id)
          .order('sent_at', { ascending: true });

        if (error) throw error;
        const msgs = (data || []) as unknown as EmailMessage[];
        setMessages(msgs);

        // Mark inbound messages as read
        const unread = msgs.filter((m) => !m.is_read && !m.is_outbound);
        if (unread.length > 0) {
          await supabase
            .from('email_messages')
            .update({ is_read: true })
            .in('id', unread.map((m) => m.id));
          await supabase
            .from('email_threads')
            .update({ unread_count: 0 })
            .eq('id', thread.id);
        }

        // Collapse all but the last message
        if (msgs.length > 1) {
          setCollapsed(new Set(msgs.slice(0, -1).map((m) => m.id)));
        }
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
  }, [thread.id]);

  const toggleCollapse = (id: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Loader2 size={24} className="text-gray-300 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <p className="text-sm text-gray-500">Не удалось загрузить переписку</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-3 text-sm text-blue-600 hover:text-blue-700 font-medium"
        >
          Повторить
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-gray-100 shrink-0">
        <div className="flex items-center gap-3 mb-2">
          <button
            onClick={onBack}
            className="p-1.5 -ml-1.5 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h2 className="text-base font-semibold text-gray-900 truncate flex-1">{thread.subject}</h2>
          <button
            onClick={() => onReply(thread)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Reply size={15} />
            Ответить
          </button>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-5 py-4 space-y-3">
          {/* Request context card */}
          {thread.request && (
            <div className="bg-gradient-to-b from-gray-50 to-white border border-gray-200 rounded-xl p-3.5 mb-2">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Заявка</p>
                  <p className="text-sm font-medium text-gray-900">
                    {thread.request.title} · <span className="font-mono text-gray-500">{thread.request.number}</span>
                  </p>
                  {thread.supplier && (
                    <p className="text-sm text-gray-500 mt-0.5">{thread.supplier.name}</p>
                  )}
                  <div className="flex items-center gap-2 mt-2">
                    <span className={cn(
                      'inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-md',
                      COMM_STATUS_COLORS[thread.request.communication_status] || '',
                    )}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      {COMM_STATUS_LABELS[thread.request.communication_status] || thread.request.communication_status}
                    </span>
                  </div>
                </div>
                {onOpenRequest && (
                  <button
                    onClick={() => onOpenRequest(thread.request!.id)}
                    className="inline-flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 font-medium shrink-0"
                  >
                    Открыть заявку
                    <ExternalLink size={13} />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Messages */}
          {messages.map((msg, idx) => {
            const isCollapsed = collapsed.has(msg.id);
            const isLast = idx === messages.length - 1;
            const avatarColor = getAvatarColor(msg.from_name);
            const initials = getInitials(msg.from_name);

            return (
              <div
                key={msg.id}
                className={cn(
                  'border border-gray-200 rounded-xl overflow-hidden transition-all duration-200',
                  isLast && 'shadow-sm',
                )}
              >
                {/* Message header */}
                <button
                  onClick={() => toggleCollapse(msg.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                >
                  <div className={cn(
                    'w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold shrink-0',
                    msg.is_outbound ? 'bg-gray-200 text-gray-600' : avatarColor,
                  )}>
                    {initials}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-gray-900 truncate">{msg.from_name}</span>
                      {msg.is_outbound && (
                        <span className="text-xs text-gray-400">(отправлено)</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 truncate">{msg.from_email}</p>
                  </div>
                  <span className="text-xs text-gray-400 shrink-0">
                    {formatFullDate(msg.sent_at)}
                  </span>
                  {messages.length > 1 && (
                    <div className="shrink-0 text-gray-400">
                      {isCollapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                    </div>
                  )}
                </button>

                {/* Message body */}
                {!isCollapsed && (
                  <div className="px-4 pb-4 animate-in fade-in duration-200">
                    <div className="border-t border-gray-100 pt-3">
                      <EmailRenderer
                        html={msg.body_html}
                        text={msg.body_text}
                      />

                      {/* Attachments */}
                      {msg.attachments && msg.attachments.length > 0 && (
                        <div className="mt-4 space-y-2">
                          {msg.attachments.map((att) => (
                            <AttachmentCard key={att.id} attachment={att} />
                          ))}
                        </div>
                      )}

                      {/* Forward button */}
                      <div className="mt-4 flex items-center gap-2">
                        <button
                          onClick={() => onForward(thread, msg)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
                        >
                          <Forward size={13} />
                          Переслать
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Supplier info at bottom */}
          {thread.supplier && (
            <div className="pt-2 pb-4">
              <div className="flex items-center gap-2 text-sm">
                <span className="text-gray-400">Отправитель связан с поставщиком:</span>
                <button className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium">
                  Профиль поставщика
                  <ExternalLink size={12} />
                </button>
              </div>
            </div>
          )}

          {/* Unknown sender */}
          {!thread.supplier && !thread.request && messages.length > 0 && !messages[0].is_outbound && (
            <div className="pt-2 pb-4">
              <div className="flex items-center gap-1.5 text-sm text-gray-400">
                <UserX size={14} />
                <span>Неизвестный отправитель</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AttachmentCard({ attachment }: { attachment: EmailAttachment }) {
  const icon = getFileIcon(attachment.filename, attachment.mime_type);

  return (
    <div className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-lg p-3 hover:border-gray-300 transition-colors group">
      <div className="w-9 h-9 rounded-lg bg-white border border-gray-200 flex items-center justify-center shrink-0">
        <span className="text-sm">{icon}</span>
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-gray-900 truncate">{attachment.filename}</p>
        <p className="text-xs text-gray-400">
          {getFileTypeLabel(attachment.mime_type)} · {formatFileSize(attachment.size_bytes)}
        </p>
      </div>
      {attachment.download_url && (
        <a
          href={attachment.download_url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-gray-600 hover:text-gray-900 hover:bg-white rounded-md transition-colors shrink-0"
        >
          <Download size={14} />
          Скачать
        </a>
      )}
    </div>
  );
}

function getFileIcon(filename: string, mime: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  if (mime.includes('pdf') || ext === 'pdf') return '📄';
  if (mime.includes('sheet') || ext === 'xlsx' || ext === 'xls') return '📊';
  if (mime.includes('word') || ext === 'docx' || ext === 'doc') return '📝';
  if (mime.includes('image') || ['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) return '🖼️';
  if (ext === 'zip' || ext === 'rar' || ext === '7z') return '🗜️';
  return '📎';
}

function getFileTypeLabel(mime: string): string {
  if (mime.includes('pdf')) return 'PDF';
  if (mime.includes('sheet')) return 'Excel';
  if (mime.includes('word')) return 'Word';
  if (mime.includes('image')) return 'Изображение';
  if (mime.includes('zip')) return 'Архив';
  return 'Файл';
}
