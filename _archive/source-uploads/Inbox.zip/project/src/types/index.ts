export type Folder = 'inbox' | 'sent' | 'drafts' | 'archive';

export type CommunicationStatus = 'awaiting_reply' | 'reply_received' | 'needs_processing';

export type MailMode = 'all' | 'requests';

export type RequestFilter = 'all' | 'awaiting_reply' | 'reply_received' | 'needs_processing';

export interface Supplier {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  contact_person: string | null;
  created_at: string;
}

export interface Request {
  id: string;
  number: string;
  title: string;
  supplier_id: string | null;
  status: string;
  communication_status: CommunicationStatus;
  created_at: string;
  supplier?: Supplier | null;
}

export interface EmailAttachment {
  id: string;
  message_id: string;
  filename: string;
  mime_type: string;
  size_bytes: number;
  download_url: string | null;
}

export interface EmailMessage {
  id: string;
  thread_id: string;
  from_name: string;
  from_email: string;
  to_email: string;
  cc_email: string | null;
  body_html: string | null;
  body_text: string | null;
  is_outbound: boolean;
  is_read: boolean;
  sent_at: string;
  created_at: string;
  attachments?: EmailAttachment[];
}

export interface EmailThread {
  id: string;
  subject: string;
  folder: Folder;
  request_id: string | null;
  supplier_id: string | null;
  last_message_at: string;
  unread_count: number;
  created_at: string;
  request?: Request | null;
  supplier?: Supplier | null;
  messages?: EmailMessage[];
  last_message?: EmailMessage | null;
}
