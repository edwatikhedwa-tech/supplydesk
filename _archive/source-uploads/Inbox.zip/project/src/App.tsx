import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Sidebar, type View } from '@/components/Sidebar';
import { Dashboard } from '@/components/Dashboard';
import { RequestsView } from '@/components/RequestsView';
import { MailView } from '@/components/MailView';
import type { ComposerContext } from '@/components/Composer';
import type { Request, Supplier } from '@/types';

const COMPACT_KEY = 'supplydesk-sidebar-compact';

function App() {
  const [view, setView] = useState<View>('dashboard');
  const [unreadCount, setUnreadCount] = useState(0);
  const [preselectedThreadId, setPreselectedThreadId] = useState<string | null>(null);
  const [composerContext, setComposerContext] = useState<ComposerContext | null>(null);
  const [compact, setCompact] = useState(() => {
    try {
      return localStorage.getItem(COMPACT_KEY) === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('email_threads')
        .select('unread_count')
        .eq('folder', 'inbox')
        .gt('unread_count', 0);
      setUnreadCount(data?.length || 0);
    })();
  }, [view]);

  const handleToggleCompact = () => {
    setCompact((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(COMPACT_KEY, String(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const handleSendRequest = (request: Request, supplier: Supplier | null) => {
    const ctx: ComposerContext = {
      to: supplier?.email || '',
      toName: supplier?.name || '',
      subject: `Запрос КП — ${request.title}`,
      requestId: request.id,
      supplierId: supplier?.id,
      body: `<p>Добрый день!</p><p>Просим предоставить коммерческое предложение по заявке ${request.number} — ${request.title}.</p><p>С уважением,<br>Отдел снабжения Supplydesk</p>`,
    };
    setComposerContext(ctx);
    setView('mail');
  };

  const handleOpenRequest = (requestId: string) => {
    setView('requests');
  };

  return (
    <div className="flex h-screen bg-gray-50 text-gray-900 overflow-hidden">
      <Sidebar
        current={view}
        onNavigate={setView}
        unreadCount={unreadCount}
        compact={compact}
        onToggleCompact={handleToggleCompact}
      />
      <main className="flex-1 flex overflow-hidden">
        {view === 'dashboard' && (
          <div className="flex-1 overflow-y-auto">
            <Dashboard
              onNavigateMail={() => setView('mail')}
              onNavigateRequests={() => setView('requests')}
            />
          </div>
        )}
        {view === 'requests' && (
          <div className="flex-1 overflow-y-auto">
            <RequestsView
              onOpenRequest={() => {}}
              onSendRequest={handleSendRequest}
            />
          </div>
        )}
        {view === 'mail' && (
          <MailView
            preselectedThreadId={preselectedThreadId}
            composerContext={composerContext}
            onComposerConsumed={() => setComposerContext(null)}
            onOpenRequest={handleOpenRequest}
          />
        )}
      </main>
    </div>
  );
}

export default App;
