/*
# Supplydesk — suppliers, requests, and email schema

1. New Tables
- `suppliers`: vendor directory (name, email, phone, contact person)
- `requests`: procurement requests linked to a supplier (number, title, status, communication status)
- `email_threads`: conversation threads, optionally linked to a request and supplier
- `email_messages`: individual messages within a thread (from/to/cc, html body, plain body, read flag)
- `email_attachments`: files attached to a message (filename, mime type, size, download url)

2. Relationships
- requests.supplier_id -> suppliers.id
- email_threads.request_id -> requests.id (nullable)
- email_threads.supplier_id -> suppliers.id (nullable)
- email_messages.thread_id -> email_threads.id
- email_attachments.message_id -> email_messages.id

3. Security
- Single-tenant (no auth). RLS enabled on every table.
- All CRUD open to anon + authenticated (intentionally shared data).

4. Notes
- Folders are an enum: inbox, sent, drafts, archive.
- Communication status on requests: awaiting_reply, reply_received, needs_processing.
- email_threads.folder stores the folder for the thread.
- email_messages.is_outbound distinguishes sent vs received messages.
*/

CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  contact_person text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number text NOT NULL UNIQUE,
  title text NOT NULL,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'open',
  communication_status text NOT NULL DEFAULT 'awaiting_reply',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text NOT NULL,
  folder text NOT NULL DEFAULT 'inbox',
  request_id uuid REFERENCES requests(id) ON DELETE SET NULL,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  last_message_at timestamptz DEFAULT now(),
  unread_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES email_threads(id) ON DELETE CASCADE,
  from_name text NOT NULL,
  from_email text NOT NULL,
  to_email text NOT NULL,
  cc_email text,
  body_html text,
  body_text text,
  is_outbound boolean NOT NULL DEFAULT false,
  is_read boolean NOT NULL DEFAULT false,
  sent_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES email_messages(id) ON DELETE CASCADE,
  filename text NOT NULL,
  mime_type text NOT NULL DEFAULT 'application/octet-stream',
  size_bytes bigint NOT NULL DEFAULT 0,
  download_url text
);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_attachments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_suppliers" ON suppliers;
CREATE POLICY "anon_crud_suppliers" ON suppliers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_suppliers" ON suppliers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_suppliers" ON suppliers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_suppliers" ON suppliers FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_requests" ON requests;
CREATE POLICY "anon_crud_requests" ON requests FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_requests" ON requests FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_requests" ON requests FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_requests" ON requests FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_threads" ON email_threads;
CREATE POLICY "anon_crud_threads" ON email_threads FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_threads" ON email_threads FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_threads" ON email_threads FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_threads" ON email_threads FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_messages" ON email_messages;
CREATE POLICY "anon_crud_messages" ON email_messages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_messages" ON email_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_messages" ON email_messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_messages" ON email_messages FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_attachments" ON email_attachments;
CREATE POLICY "anon_crud_attachments" ON email_attachments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_attachments" ON email_attachments FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_attachments" ON email_attachments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_attachments" ON email_attachments FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_threads_folder ON email_threads(folder);
CREATE INDEX IF NOT EXISTS idx_threads_request ON email_threads(request_id);
CREATE INDEX IF NOT EXISTS idx_threads_supplier ON email_threads(supplier_id);
CREATE INDEX IF NOT EXISTS idx_messages_thread ON email_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_attachments_message ON email_attachments(message_id);
